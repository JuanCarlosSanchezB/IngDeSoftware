package com.example.ejemplonavigation;

import java.util.List;

public class Orders
{
    public static List<Order> lista;
}
